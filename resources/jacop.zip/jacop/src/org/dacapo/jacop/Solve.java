package org.dacapo.jacop;

import java.io.File;
import java.nio.file.Path;
import org.jacop.fz.Fz2jacop;

public class Solve {
    private static final String[] challenges = new String[] {
        "mapping/full2x2_mp3.fzn",
        "oocsp_racks/oocsp_racks_050_r1.fzn",
        "oocsp_racks/oocsp_racks_100_r1_cc.fzn",
        "soccer-computational/xIGData_22_12_22_5.fzn",
        "test-scheduling/t30m10r10-5.fzn",
        "test-scheduling/t30m10r3-15.fzn"
    };

    public void main(String[] args, File data) {

        /* Note: The benchmark driver must allocate an extra
                 slot for the challenge path in 'args'. */

        /* Note: Arguments are passed from jacop.cnf. */

        final int  fileIndex = args.length - 1;
        final Path dat       = data.toPath().resolve("dat/jacop");
        for (String challenge: challenges) {

            /* Solve challenge using JaCoP. */

            args[fileIndex] = dat.resolve(challenge).toString();

            Fz2jacop.main(args);
        }
    }
}
