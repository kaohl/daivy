package org.dacapo.jacop;

import java.io.File;
import java.nio.file.Path;
import org.jacop.fz.Fz2jacop;

public class Solve {
    public void main(String[] args, File data) {
        Fz2jacop.main(args);
    }
}
