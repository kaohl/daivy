package org.dacapo.harness;

import java.io.File;
import java.lang.reflect.Constructor;

import org.dacapo.harness.Benchmark;
import org.dacapo.parser.Config;

public class Jacop extends Benchmark {
    private final Object benchmark;
    private String[] args;

    public Jacop(Config config, File scratch, File data) throws Exception {
        super(config, scratch, data);
        Class<?> clazz = Class.forName("org.dacapo.jacop.Solve", true, loader);
        this.method = clazz.getMethod("main", new Class[] { String[].class, File.class });
        Constructor<?> cons = clazz.getConstructor();
        useBenchmarkClassLoader();
        try {
            benchmark = cons.newInstance();
        } finally {
            revertClassLoader();
        }
    }

    @Override
    protected void prepare(String size) throws Exception {
        super.prepare(size);
        this.args = config.preprocessArgs(size, scratch, this.data);
    }

    public void iterate(String size) throws Exception {
        method.invoke(benchmark, new Object[] { args, this.data });
    }
}
